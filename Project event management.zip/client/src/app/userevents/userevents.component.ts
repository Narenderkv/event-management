import { Component, Input } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-userevents',
  templateUrl: './userevents.component.html',
  styleUrls: ['./userevents.component.scss']
})
export class UsereventsComponent {
   @Input() audienceData: any;
  data:any;
  email:any;
   constructor( private apiservice: ApiService) {
        this.email = this.apiservice.getEmail();

    this.fetchevents();
    console.log(this.email,'asdfas');
    
  }
  fetchevents() {
    this.apiservice.userevents(this.email).subscribe((data: any) => {
      this.data = data;
    });
  }
}
