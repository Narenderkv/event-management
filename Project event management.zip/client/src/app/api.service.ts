// gaurav
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, Subject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ApiService {
    public serviceBase = environment.API_URL;
        public imageBase: any = environment.IMAGE_URL;

    public headers = new HttpHeaders({
        'Content-Type': 'application/json'
    });
    public loadingShow: boolean = false;
    constructor(
        private router: Router,
        private http: HttpClient,
       ) {

    }
  private email: any;

  setEmail(email: string) {
    this.email = email;
    console.log(this.email,'this is email');
    
  }

  getEmail(): string {
        console.log(this.email,'this is email2');

    return this.email;

  }


    get(url: string) {
        
        return this.http.get(this.serviceBase + url, { headers: this.headers });
    }
    post(url: string, data: any) {

        return this.http.post(this.serviceBase + url, data, { headers: this.headers });
    }
    getAudiencesForEvent(eventId: string) {
        console.log(eventId,'adsa');
        
    return this.http.get(`${this.serviceBase}events/${eventId}/audiences`);
    }
    userevents(email: string) {
        
    return this.http.get(`${this.serviceBase}users/${email}/events`);
    }
    registerAudience(eventId: string, audienceData: any): Observable<any> {
    const url = `${this.serviceBase}events/${eventId}/register`;
    return this.http.post(url, audienceData);
  }
 postFile(fileToUpload: File) {
  console.log('this is api call', fileToUpload);

  const formData: FormData = new FormData();
  formData.append('attachment', fileToUpload, fileToUpload.name); // 'attachment' should match your server's expected field name

  return this.http.post(this.serviceBase + 'upload_file', formData);
}
}