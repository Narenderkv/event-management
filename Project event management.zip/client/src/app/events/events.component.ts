import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { NgxSmartModalService } from 'ngx-smart-modal';
import { ApiService } from '../api.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss']
})
export class EventsComponent {
name = 'Angular 6';
  @ViewChild('myform') form: NgForm | undefined;
  data: any;
  editMode = false;
  editIndex: any;
  addForm: FormGroup | any;
  bodyparser:any
  filteredEvents: any; // To store filtered events
  filterDate: string = '';
  filterLocation: string = '';
  constructor(public sanitizer: DomSanitizer,private fb: FormBuilder, public ngxSmartModalService: NgxSmartModalService, public apiservice: ApiService) {
    this.emp_list();
  }

  ngOnInit(): void {
    this.addForm =  this.fb.group({
      EventId: ['', Validators.required],
      EventName: ['', Validators.required],
      EventDate: ['', Validators.required],
      EventTime: ['', Validators.required],
      Location: ['', Validators.required],
       
    });
  }

  emp_list() {
    this.apiservice.get("events").subscribe((res: any) => {
      this.data = res;
      this.filteredEvents=res;
      console.log("data", this.data);
    });
  }
applyFilters() {
  console.log('Filtering...');
  console.log('Filter Date:', this.filterDate);
  console.log('Filter Location:', this.filterLocation);

  this.data = this.filteredEvents.filter((event:any) => {
    const formattedEventDate = event.EventDate.substring(0, 10); 

    const dateMatch = !this.filterDate || formattedEventDate === this.filterDate;

    const locationMatch = !this.filterLocation || event.Location.includes(this.filterLocation);

    return dateMatch && locationMatch;
  });
}

clearFilters(){
  this.filterDate=""
this.filterLocation=""
this. emp_list()
}
  addData() {
    var val: any = this.addForm.value;
val.EventImages= this.selectedImageFile;
console.log(val,'this is val');

    console.log(this.selectedImageFile, 'this is data');
    
    this.apiservice.post("events", val).subscribe((res: any) => {
      this.emp_list();
      this.addForm.reset();
      this.ngxSmartModalService.close('myModal');
    });
  }
selectedImageFile: any;

handleImageInput(event: any) {
  const fileToUpload = event.files[0]; // Get the selected file

  this.apiservice.postFile(fileToUpload).subscribe((data: any) => {
    this.selectedImageFile = data.name;
  }, error => {
    console.log(error);
  });
}


  closeModal(id: any) {
    this.form?.resetForm();
    this.editMode = false;
    this.ngxSmartModalService.close(id);
  }
   allowurl(url: any) {
    console.log(url);

    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    
  }
 
}