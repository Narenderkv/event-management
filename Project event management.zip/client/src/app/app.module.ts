import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';


import { AppComponent } from './app.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { NgxSmartModalModule,NgxSmartModalService } from 'ngx-smart-modal';
import { EventsComponent } from './events/events.component';
import { EventUserComponent } from './event-user/event-user.component';
import { AppRoutingModule } from './app-routing.module';
import { UsereventsComponent } from './userevents/userevents.component';

@NgModule({
  declarations: [
    AppComponent,
    EventsComponent,
    EventUserComponent,
    UsereventsComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,RouterModule,
    FormsModule,NgxSmartModalModule.forRoot(),ReactiveFormsModule, AppRoutingModule
  ],
  providers: [NgxSmartModalService],
  bootstrap: [AppComponent]
})
export class AppModule { }
