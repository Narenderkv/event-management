import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { NgxSmartModalService } from 'ngx-smart-modal';
import { ApiService } from './api.service';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.scss' ]
})
export class AppComponent {
 ngAfterViewInit() {
    // setTimeout(() => {
    //   let loader = this.renderer.selectRootElement('#loader');
    //   this.renderer.setStyle(loader, 'display', 'none');

    // }, 2000);
  }
  ngOnInit() {}
}
