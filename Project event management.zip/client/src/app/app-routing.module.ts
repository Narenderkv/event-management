import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { EventsComponent } from './events/events.component';
import { EventUserComponent } from './event-user/event-user.component';
import { UsereventsComponent } from './userevents/userevents.component';

const routes: Routes = [
 
   
      { path: '', component: EventsComponent },
      { path: 'eventuser/:eventId', component: EventUserComponent },
      { path: 'userevent', component: UsereventsComponent },

 
];
@NgModule({
  declarations: [],
  imports: [RouterModule.forRoot(routes),
    CommonModule
  ],
  exports: [RouterModule]
})

export class AppRoutingModule { }

