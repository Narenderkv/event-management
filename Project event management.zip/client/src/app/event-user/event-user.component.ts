import { Component, ViewChild } from '@angular/core';
import { ApiService } from '../api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { NgxSmartModalService } from 'ngx-smart-modal';

@Component({
  selector: 'app-event-user',
  templateUrl: './event-user.component.html',
  styleUrls: ['./event-user.component.scss']
})
export class EventUserComponent {
   @ViewChild('myform') form: NgForm | undefined;
  data: any;
  editMode = false;
  editIndex: any;
  addForm: FormGroup | any;
  bodyparser:any
  eventId!: string;
  audiences: any;

    constructor( private router: Router,public ngxSmartModalService: NgxSmartModalService,private fb: FormBuilder,private route: ActivatedRoute, private eventService: ApiService) {}

ngOnInit() {
   this.addForm =  this.fb.group({
      Name: ['', Validators.required],     
      Email: ['', Validators.required]
    });
    this.route.params.subscribe((params:any) => {
      console.log(params,'params');      
      this.eventId = params['eventId'];
      this.fetchAudiences();
    });
  }
  fetchAudiences() {
    this.eventService.getAudiencesForEvent(this.eventId).subscribe((data: any) => {
      this.audiences = data;
    });
  }
   

  
 registerAudienceForEvent() {
  var val: any = this.addForm.value;
    this.eventService.registerAudience(this.eventId, val).subscribe(
      (response) => {
        console.log('Audience registered successfully:', response);
        this.addForm.reset();
      this.ngxSmartModalService.close('myModal');
      this.fetchAudiences()
      },
      (error) => {
        console.error('Error registering audience:', error);
      }
    );
  }

  closeModal(id: any) {
    this.form?.resetForm();
    this.editMode = false;
    this.ngxSmartModalService.close(id);
  }
 setEmailToService(email: string) {
    this.eventService.setEmail(email);
    this.router.navigate(['/userevent'])
  }
}
