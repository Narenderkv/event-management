export const environment = {
  production: true,
   api_url: 'http://localhost:3000/',
	 imageBase_api_url : 'http://localhost:3000/uploads/'
};
