
export const environment = {
  production: false,
  API_URL: 'http://localhost:3000/',
 	IMAGE_URL : 'http://localhost:3000/uploads/'

};

