const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const Event = require('./models/event');
const Audience = require('./models/audience');
const multer = require('multer');

const app = express();
const port = process.env.PORT || 3000;
const mongoURI = 'mongodb://localhost:27017/eventdb';
const cors = require('cors');
app.use(cors({ origin: true, credentials: true }));
mongoose.connect(mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

mongoose.connection.on('connected', () => {
    console.log('Connected to MongoDB');
});

mongoose.connection.on('error', (err) => {
    console.error('Error connecting to MongoDB: ' + err);
});

app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Set up multer for image uploads
var storage = multer.diskStorage({
    destination: function (req, file, cb) {

        cb(null, './uploads/')
    },
    filename: function (req, file, cb) {
        console.log('file', file)
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
})

var upload = multer({ storage: storage });



app.post("/upload_file", upload.single('attachment'), function (req, res) {

    console.log(req, res, 'userimg');


    //return false;
    if (req.method == 'POST') {
        console.log("req.body>>>>>>>attachment", req.body);
        //console.log("req>>>>>>>>>>>>>>>>>>",req);
        const file = req.file;
        console.log("file>>>>>>>>>>>>>>>>>", file);
        //return false;
        try {
            return res.send({ status: true, msg: 'Record added succesfully.', name: file.filename })
        } catch (error) {
            console.log('err', error);
        }
    }
})

// Create an event (Promise way)
app.post('/events', async (req, res) => {
    try {
        const event = new Event({
            EventId: req.body.EventId,
            EventName: req.body.EventName,
            EventDate: req.body.EventDate,
            EventTime: req.body.EventTime,
            Location: req.body.Location,
            EventImages: req.body.EventImages, // Store the uploaded image path
            Details: req.body.Details,
        });

        await event.save();
        res.status(201).json(event);
    } catch (error) {
        console.error('Error creating event:', error);

        res.status(400).json({ error: 'Unable to create event' });
    }
});

// Get all events (Promise way)
app.get('/events', async (req, res) => {
    try {
        const events = await Event.find();
        res.json(events);
    } catch (error) {
        res.status(500).json({ error: 'Unable to fetch events' });
    }
});


app.post('/events/:eventId/register', async (req, res) => {
    try {
        const eventId = req.params.eventId;

        // Check if an event with the given eventId exists
        const event = await Event.findOne({ EventId: eventId });

        if (!event) {
            console.log('Event not found');
            return res.status(404).json({ error: 'Event not found' });
        }

        const { Name, Email } = req.body;

        // Check if an audience with the same email and event ID already exists
        const existingAudience = await Audience.findOne({ EventId: eventId, Email });

        if (existingAudience) {
            console.log('Audience with the same email already registered for this event');
            return res.status(400).json({ error: 'Audience with the same email already registered for this event' });
        }

        const audienceData = {
            EventId: eventId,
            Name,
            Email,
        };

        const audience = new Audience(audienceData);
        await audience.save();

        res.status(201).json(audience);
    } catch (error) {
        console.error('Error registering audience:', error);
        res.status(400).json({ error: 'Unable to register audience' });
    }
});







app.get('/users/:userEmail/events', async (req, res) => {
    const userEmail = req.params.userEmail;

    try {
        // Fetch all audiences with the given user's email
        const audiences = await Audience.find({ Email: userEmail });
        console.log(audiences, ' audiences');
        // Extract EventIds from the audiences
        const eventIds = audiences.map((audience) => audience.EventId);
        console.log(eventIds, ' eventIds');

        // Fetch events based on the extracted EventIds
        const events = await Event.find({ EventId: eventIds });
        console.log(events, ' events');

        res.json(events);
    } catch (error) {
        res.status(500).json({ error: 'Unable to fetch user events' });
    }
});

app.get('/events/:eventId/audiences', async (req, res) => {
    try {
        const eventId = req.params.eventId;

        // Check if an event with the given eventId exists
        const event = await Event.findOne({ EventId: eventId });

        if (!event) {
            console.log('Event not found');
            return res.status(404).json({ error: 'Event not found' });
        }

        // Fetch audiences for the specified event
        const audiences = await Audience.find({ EventId: eventId });

        res.json(audiences);
    } catch (error) {
        console.error('Error fetching audiences:', error);
        res.status(500).json({ error: 'Unable to fetch audiences' });
    }
});


app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
