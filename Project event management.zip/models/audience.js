const mongoose = require('mongoose');

const audienceSchema = new mongoose.Schema({
    EventId: {
        type: String,
        ref: 'Event',
        required: true,
    },
    Name: {
        type: String,
        required: true,
    },
    Email: {
        type: String,
        required: true,
    },
    // Add other audience registration fields here
});

module.exports = mongoose.model('Audience', audienceSchema);
