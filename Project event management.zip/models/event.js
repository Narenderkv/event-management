const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
    EventId: {
        type: String,
        required: true,
        unique: true,
    },
    EventName: {
        type: String,
        required: true,
    },
    EventDate: {
        type: Date,
        required: true,
    },
    EventTime: {
        type: String,
        required: true,
    },
    Location: {
        type: String,
        required: true,
    },
    EventImages: [
        {
            type: String,
        },
    ],
    Details: {
        type: String,
    },
});

module.exports = mongoose.model('Event', eventSchema);
